# 第二次挑战

## 1、GPU 与软件版本

| 项目 | 版本 / 配置 |
|---|---|
| GPU | NVIDIA GeForce RTX 3060 Laptop GPU，6 GB |
| 系统 | WSL2 / Ubuntu 24.04 |
| Python | 3.12.3 |
| SGLang | 0.5.14 |
| Ray | 2.56.0 |
| PyTorch | 2.11.0 |
| Transformers | 5.8.1 |
| aiohttp | 3.14.3 |
| NVIDIA 驱动 | 596.49 |
| CUDA Toolkit | 13.0 |
| CUDA（驱动支持） | 13.2 |
| 模型 | Qwen/Qwen3-0.6B |

## 2、安装方法

### 2.1 安装 WSL2 与 Ubuntu 24.04

使用 Windows 11，或 Windows 10 2004（内部版本 19041）及以上版本。在任务管理器的“性能 → CPU”中确认“虚拟化”已启用；未启用时，进入电脑 BIOS/UEFI 开启 Intel VT-x 或 AMD SVM。

以管理员身份打开 PowerShell，安装 WSL 和 Ubuntu：[微软安装说明](https://learn.microsoft.com/en-us/windows/wsl/install)。

```powershell
wsl --install -d Ubuntu-24.04
```

按提示重启 Windows，从开始菜单打开 Ubuntu 24.04，等待初始化完成，设置 Linux 用户名和密码。输入密码时终端不显示字符。

回到管理员 PowerShell，更新 WSL 并确认 Ubuntu 使用 WSL2：

```powershell
wsl --update
wsl --set-version Ubuntu-24.04 2
wsl --list --verbose
```

确认 Ubuntu-24.04 的 `VERSION` 为 `2`。如果发行版下载一直停在 0%，使用：

```powershell
wsl --install --web-download -d Ubuntu-24.04
```

### 2.2 安装 Windows NVIDIA 驱动

打开 [NVIDIA 驱动下载页面](https://www.nvidia.com/en-us/drivers/)，选择显卡和 Windows 版本。RTX 3060 Laptop 对应 GeForce RTX 30 Series（Notebooks）中的 GeForce RTX 3060 Laptop GPU。下载支持 CUDA 13.0 的 Windows 驱动；本实验使用 596.49，也可使用支持该显卡的更新驱动。

运行下载的安装程序，按默认选项完成安装并重启 Windows。在 PowerShell 中检查：

```powershell
nvidia-smi
```

随后打开 Ubuntu，再执行：

```bash
nvidia-smi
```

两处均应显示显卡名称和驱动版本。Ubuntu 中若找不到命令，可执行 `/usr/lib/wsl/lib/nvidia-smi`。驱动安装在 Windows；WSL 内不安装 Linux NVIDIA 驱动，见 [NVIDIA WSL 指南](https://docs.nvidia.com/cuda/archive/13.0.0/wsl-user-guide/index.html)。

### 2.3 安装 Ubuntu 基础工具与 CUDA Toolkit 13.0

以下命令在 Ubuntu 终端执行。安装 Python、编译工具和下载工具：

```bash
sudo apt-get update
sudo apt-get install -y python3.12 python3.12-venv python3-pip \
  build-essential git curl wget ca-certificates
```

添加 NVIDIA 的 WSL-Ubuntu 软件源，安装 CUDA Toolkit 13.0：[CUDA 13.0 下载页面](https://developer.nvidia.com/cuda-13-0-0-download-archive?target_os=Linux&target_arch=x86_64&Distribution=WSL-Ubuntu&target_version=2.0&target_type=deb_network)。

```bash
mkdir -p ~/downloads/cuda
cd ~/downloads/cuda
wget -O cuda-keyring_1.1-1_all.deb \
  https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-keyring_1.1-1_all.deb
sudo dpkg -i cuda-keyring_1.1-1_all.deb
sudo apt-get update
sudo apt-get install -y cuda-toolkit-13-0
```

将 CUDA 路径写入终端配置并立即生效：

```bash
cat >> ~/.bashrc <<'EOF'

export CUDA_HOME=/usr/local/cuda-13.0
export PATH="$CUDA_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$CUDA_HOME/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
EOF
source ~/.bashrc
nvcc --version
```

确认输出包含 `release 13.0`。

### 2.4 放置实验文件并创建 Python 环境

在 Ubuntu 中建立工作目录，并用文件资源管理器打开：

```bash
mkdir -p ~/lab
cd ~/lab
explorer.exe .
```

把解压得到的整个 `HW2-052502222` 文件夹复制到打开的位置。复制完成后，目录应为 `~/lab/HW2-052502222/`，其中包含 `README.md`、`src/`、`results/` 等文件。回到 Ubuntu 执行：

```bash
cd ~/lab/HW2-052502222
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install uv
```

安装 [PyTorch 2.11.0 的 CUDA 13.0 版本](https://pytorch.org/get-started/previous-versions/#v2110)，再安装 SGLang、Ray 和实验依赖：

```bash
uv pip install torch==2.11.0 torchvision==0.26.0 torchaudio==2.11.0 \
  --index-url https://download.pytorch.org/whl/cu130
uv pip install --prerelease=allow \
  -r src/target1/requirements-recorded.txt "ray[default]==2.56.0"
```

按 [SGLang v0.5.14 的 CUDA 13 安装说明](https://github.com/sgl-project/sglang/blob/v0.5.14/docs/get_started/install.md)，安装对应的 CUDA 13 kernel：

```bash
uv pip install "https://github.com/sgl-project/whl/releases/download/v0.4.4/sglang_kernel-0.4.4+cu130-cp310-abi3-manylinux2014_x86_64.whl"
python -m pip check
```

检查软件版本，并执行一次 GPU 运算：

```bash
python - <<'PY'
import sys
import torch
from importlib.metadata import version

print("Python:", sys.version.split()[0])
for name in ("sglang", "ray", "torch", "transformers", "aiohttp"):
    print(f"{name}: {version(name)}")
print("PyTorch CUDA:", torch.version.cuda)
assert torch.cuda.is_available(), "CUDA 不可用"
print("GPU:", torch.cuda.get_device_name(0))
print("GPU 运算:", (torch.ones(3, device="cuda") * 2).tolist())
PY
```

确认 SGLang 为 `0.5.14`、Ray 为 `2.56.0`，GPU 运算输出 `[2.0, 2.0, 2.0]`。

### 2.5 下载模型

在已激活的虚拟环境中下载模型到 Hugging Face 缓存：[Hugging Face 下载命令说明](https://huggingface.co/docs/huggingface_hub/guides/cli#hf-download)。

```bash
hf download Qwen/Qwen3-0.6B
```

## 3、启动与回放命令

### 启动服务

在 Ubuntu 终端中启动模型服务：

```bash
cd ~/lab/HW2-052502222
source .venv/bin/activate
python -m sglang.launch_server \
  --model-path Qwen/Qwen3-0.6B \
  --host 127.0.0.1 --port 30000 \
  --dtype auto --attention-backend flashinfer \
  --mem-fraction-static 0.339 \
  --chunked-prefill-size 2048 --max-prefill-tokens 16384 \
  --schedule-policy fcfs --page-size 1 \
  --stream-interval 1 --random-seed 630141337 \
  --cuda-graph-max-bs-decode 8
```

等待终端显示 `The server is fired up and ready to roll!`，保持该终端运行。

另开 Ubuntu 终端，检查服务并发送一条测试请求：

```bash
cd ~/lab/HW2-052502222
source .venv/bin/activate
curl -f http://127.0.0.1:30000/v1/models
curl -f http://127.0.0.1:30000/generate \
  -H 'Content-Type: application/json' \
  -d '{"text":"Hello","sampling_params":{"temperature":0,"max_new_tokens":16},"stream":false}'
```

确认模型列表包含 `Qwen/Qwen3-0.6B`，测试请求返回生成结果后，继续下面的步骤。

### 输入准备

构造本次实验输入：

```bash
python src/target1/make_inputs.py --out generated-inputs --allow-download
```

共享组为 2048 token 公共前缀加 64 token 独立后缀；分散组每条也是 2112 token，但首个 token 各不相同。两组各 32 条请求。

`src/target1/data/` 保存报告实验使用的输入。需要用原输入回放时，跳过生成步骤，将下列命令中的 `--data generated-inputs` 统一替换为 `--data src/target1/data`。

### 回放实验

在客户端终端按顺序执行。每条命令成功后再执行下一条，期间保持服务空闲，不发送其它推理请求。

```bash
cd ~/lab/HW2-052502222
source .venv/bin/activate

# 检查服务，预热服务
python src/target1/check_server.py --run-name replay-1 --data generated-inputs
python src/target1/warmup_service.py --run-name replay-1 --data generated-inputs

# 共享组：清缓存、预热前缀、测量
python src/target1/flush_cache.py --group shared_prefix --run-name replay-1 --data generated-inputs
python src/target1/warmup_prefix.py --run-name replay-1 --data generated-inputs
python src/target1/run_group.py --group shared_prefix --run-name replay-1 --data generated-inputs

# 分散组：清缓存、测量
python src/target1/flush_cache.py --group dispersed_prefix --run-name replay-1 --data generated-inputs
python src/target1/run_group.py --group dispersed_prefix --run-name replay-1 --data generated-inputs

# 生成两组汇总和对照表
python src/target1/summarize_results.py --run-name replay-1
```

确认两组均为 `32/32`，汇总显示 `PASS`。逐请求记录位于 `results/target1/shared_prefix/replay-1/` 和 `results/target1/dispersed_prefix/replay-1/`，对照表位于 `results/target1/replay-1/comparison.md`。

第二轮沿用相同输入，将以上检查服务至汇总的所有命令中的 `replay-1` 改为 `replay-2`，再次顺序执行。完成两轮后，在服务终端按 `Ctrl+C` 停止服务。

### 复算报告中的结果

无需启动服务，在已激活虚拟环境的实验目录运行：

```bash
python src/target1/summarize_results.py --run-name run-1
python src/target1/summarize_results.py --run-name run-2
```

复算后生成的对照表分别位于 `results/target1/run-1/` 和 `results/target1/run-2/`。

## 4、脚本用途

| 脚本 | 用途 |
|---|---|
| `make_inputs.py` | 构造共享前缀、分散前缀及预热输入。 |
| `check_server.py` | 检查服务版本和缓存状态，保存环境与配置。 |
| `warmup_service.py` | 发送短请求预热服务。 |
| `flush_cache.py` | 清空缓存并保存清空结果。 |
| `warmup_prefix.py` | 发送共享前缀预热请求。 |
| `run_group.py` | 测量指定组的 32 条请求，最大并发数为 8。 |
| `summarize_results.py` | 读取逐请求记录，生成汇总表和验证结果。 |
| `common.py` | 提供请求参数、流式响应解析和计时等公共函数。 |
| `metrics.py` | 计算吞吐量、命中率、Prefill token 数和延迟分位数。 |

## 5、结果文件与报告表 1 的对应关系

表 1 的 `run_1` 对应第一轮，`run_2` 对应第二轮。第一轮数据对应 `results/target1/run-1(汇总）/comparison.csv`，第二轮数据对应 `results/target1/run-2(汇总）/comparison.csv`；同目录的 `comparison.md` 可直接查看对照表。

四组数据分别来自：

- 第一轮共享组：`results/target1/shared_prefix/run-1/`
- 第一轮分散组：`results/target1/dispersed_prefix/run-1/`
- 第二轮共享组：`results/target1/shared_prefix/run-2/`
- 第二轮分散组：`results/target1/dispersed_prefix/run-2/`

下面的“分组目录”指上述四个目录，“汇总目录”指 `run-1(汇总）/`、`run-2(汇总）/`。查看结果可先读 `comparison.md`；复算报告时，脚本读取各分组目录中的 `requests.jsonl`、`measurement.json` 和 `server_info.json`。

| 文件 | 所在目录 | 用途 | 离线复算是否读取 |
|---|---|---|---|
| `requests.jsonl` | 分组目录 | 逐请求数据、计时及原始 SSE 响应，是指标计算的依据。 | 是 |
实际开启的 overlap 循环使用相同入队流程| `measurement.json` | 分组目录 | 整组耗时、并发数与请求参数；耗时用于计算吞吐量。 | 是 |
| `server_info.json` | 分组目录 | 测量时的服务配置，用于检查两组配置是否一致。 | 是 |
| `requests.csv` | 分组目录 | 便于查看的逐请求表。 | 否 |
| `summary.json` | 分组目录 | 本组汇总指标，对应报告表 1 的一列；复算时重新生成。 | 否 |
| `inputs.jsonl` | 分组目录 | 本组实际使用的输入 token ID，供追溯输入。 | 否 |
| `flush.json` | 分组目录 | 测量前清缓存的返回记录。 | 否 |
| `prefix_warmup.json` | 共享组目录 | 公共前缀预热的输入与结果，不计入测量。 | 否 |
| `comparison.md`、`comparison.csv` | 汇总目录 | 两组指标对照表，分别便于直接阅读和表格处理。 | 否 |
| `validation.json` | 汇总目录 | 数值检查是否通过、是否出现请求回退；复算时重新生成。 | 否 |
| `environment.json` | 汇总目录 | 当时的软件版本、系统与 GPU 信息。 | 否 |
| `server_info.json` | 汇总目录 | 实验开始时的服务配置快照，供核对环境。 | 否 |
| `service_warmup.json` | 汇总目录 | 正式实验前的服务预热记录，不计入测量。 | 否 |

重新运行实验使用 README 中的命令及输入文件，上述历史结果不作为新实验的输入，新运行会生成对应记录。表 1 各指标的计算方式如下：

- 成功率：`status` 为 `ok` 的请求数除以 32。
- 请求吞吐量：成功请求数除以整组测量时长。
- 输出吞吐量：`completion_tokens` 总和除以整组测量时长。
- 输入、输出、缓存 token 总数：分别累加 `prompt_tokens`、`completion_tokens`、`cached_tokens`。
- 缓存命中率：缓存 token 总数除以输入 token 总数。
- 实际 Prefill token 总数：累加 `prompt_tokens - cached_tokens`。
- TTFT、TPOT、端到端延迟的 p50/p95：分别对 `ttft_ms`、`tpot_ms`、`e2e_ms` 排序并线性插值计算。

计时标准：TTFT 从发送到首 token 到达；端到端延迟从发送到末 token 到达；TPOT 为首末 token 到达时间差除以 15。`requests.jsonl` 的 `events` 保存原始 SSE 响应和到达时间，可进一步核对这些数值。
