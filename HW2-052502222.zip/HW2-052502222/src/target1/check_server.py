"""只读取运行配置和本机环境；不发送推理请求、不清缓存。"""
import importlib.metadata
import platform
import subprocess
from pathlib import Path
from common import arguments, client, checked_server, write_json, entrypoint


async def main():
    args = arguments(__doc__)
    async with client() as session:
        info = await checked_server(session, args.url)
    config = info.get('server_args', info)
    print('SGLang version =', info['version'])
    print('model_path =', config.get('model_path'))
    print('disable_radix_cache =', config['disable_radix_cache'], '=> 前缀缓存未被禁用')
    print('stream_interval =', config.get('stream_interval'))
    out = Path(args.out) / args.run_name
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / 'server_info.json', info)
    env = {'platform': platform.platform(), 'python': platform.python_version()}
    for name in ('sglang', 'ray', 'torch', 'aiohttp', 'transformers'):
        try:
            env[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            env[name] = 'not installed in this client environment'
    try:
        proc = subprocess.run(['nvidia-smi'], capture_output=True, text=True, timeout=10)
        env['client_nvidia_smi'] = proc.stdout + proc.stderr
    except (OSError, subprocess.TimeoutExpired) as exc:
        env['client_nvidia_smi'] = str(exc)
    write_json(out / 'environment.json', env)
    print('配置及客户端环境已保存到', out)


if __name__ == '__main__':
    entrypoint(main)
