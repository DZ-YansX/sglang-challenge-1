"""只等待服务空闲并清缓存，保存清空记录；不预热、不测量。"""
from common import arguments, dataset, folder_for, client, checked_server, flush, write_json, save_state, entrypoint


async def main():
    args = arguments(__doc__, group=True)
    _, _, digest = dataset(args)
    out = folder_for(args)
    if (out / 'requests.jsonl').exists() or (out / 'measurement.json').exists():
        raise RuntimeError('本组已有测量结果，重做请使用 --run-name run-2 等新名称')
    out.mkdir(parents=True, exist_ok=True)
    save_state(args, 'flush_started', digest)
    async with client() as session:
        await checked_server(session, args.url)
        record = await flush(session, args.url)
    write_json(out / 'flush.json', record)
    save_state(args, 'flushed', digest)
    print('清缓存成功。HTTP', record['http_status'])
    print(record['response'].strip())
    if args.group == 'shared_prefix':
        print('下一步手动运行 warmup_prefix.py。')
    else:
        print('分散组不做前缀预热；下一步手动运行 run_group.py。')


if __name__ == '__main__':
    entrypoint(main)
