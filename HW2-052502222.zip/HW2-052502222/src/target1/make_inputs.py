"""只构造并保存输入，不启动模型、不发送推理请求。"""
import argparse
import math
import random
from pathlib import Path
from common import N, INPUT_LEN, PREFIX_LEN, write_json, write_jsonl, entrypoint

def make_workloads(tokenizer):
    rng = random.Random(2026)
    base = tokenizer.encode(
        "This is a controlled experiment on language model inference. "
        "The context contains information about computers, science and education. ",
        add_special_tokens=False)
    if not base:
        raise ValueError("Tokenizer produced an empty input")
    prefix = (base * math.ceil(PREFIX_LEN / len(base)))[:PREFIX_LEN]
    specials = set(tokenizer.all_special_ids)
    pool = sorted({v for v in tokenizer.get_vocab().values()
                   if 100 <= v < 10000 and v not in specials and v != prefix[0]})
    markers = rng.sample(pool, 65)
    shared, dispersed = [], []
    for i in range(N):
        # Distinct first suffix tokens prevent accidental reuse beyond 2048.
        suffix = [markers[i]] + rng.choices(pool, k=63)
        ids = prefix + suffix
        shared.append(ids)
        # Change only the first token in each paired request. Causal attention
        # means the remaining identical tokens are NOT a reusable prefix.
        dispersed.append([markers[N + i]] + ids[1:])
    # A separate 2112-token warmup includes the full prefix; its suffix is unique.
    prefix_warmup = prefix + [markers[64]] + rng.choices(pool, k=63)
    assert all(len(x) == INPUT_LEN for x in shared + dispersed)
    assert len({x[0] for x in dispersed}) == N
    assert all(x[:PREFIX_LEN] == prefix for x in shared)
    assert len({x[PREFIX_LEN] for x in shared + [prefix_warmup]}) == N + 1
    return {"shared_prefix": shared, "dispersed_prefix": dispersed}, prefix_warmup, base[:16]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tokenizer', default='Qwen/Qwen3-0.6B')
    parser.add_argument('--allow-download', action='store_true')
    parser.add_argument('--out', default=str(Path(__file__).resolve().parent / 'data'))
    args = parser.parse_args()
    out = Path(args.out)
    if out.exists() and any(out.iterdir()):
        raise RuntimeError(f'{out} 已有文件；请复用它，或用 --out 指定新目录。')
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.tokenizer, local_files_only=not args.allow_download)
    workloads, warm, short = make_workloads(tokenizer)
    out.mkdir(parents=True, exist_ok=True)
    for name, inputs in workloads.items():
        write_jsonl(out / (name+'.jsonl'), [{'request_id':i, 'input_ids':ids} for i,ids in enumerate(inputs)])
    write_json(out/'prefix_warmup.json', {'input_ids':warm})
    write_json(out/'service_warmup.json', {'input_ids':short})
    write_json(out/'config.json', {'tokenizer':args.tokenizer, 'seed':2026, 'requests_per_group':N,
                                  'input_tokens':INPUT_LEN, 'prefix_tokens':PREFIX_LEN})
    print(f'已生成输入至 {out}，没有发送任何请求。')
    print('共享组：32 条，每条 2048+64 token；分散组：32 条，每条 2112 token、首 token 各异。')
    print('分散组与对应共享组仅首 token 不同；完整 ID 列表已保存。')

if __name__ == '__main__':
    entrypoint(main)
